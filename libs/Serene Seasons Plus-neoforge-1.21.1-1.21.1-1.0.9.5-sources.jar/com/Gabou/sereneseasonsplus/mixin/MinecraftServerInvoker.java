package com.Gabou.sereneseasonsplus.mixin;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;
@Mixin(MinecraftServer.class)
public interface MinecraftServerInvoker {
    @Invoker("haveTime")
    public boolean tempsEcoule();
}